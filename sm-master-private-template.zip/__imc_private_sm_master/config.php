<?php
declare(strict_types=1);
return [
  'db' => [
    'host' => '31.11.39.163',
    'database' => 'Sql1956795_1',
    'user' => 'Sql1956795',
    'password' => '__INSERT_MYSQL_PASSWORD__',
  ],
  'admin_token' => '__INSERT_PRIVATE_ADMIN_TOKEN__',
];
